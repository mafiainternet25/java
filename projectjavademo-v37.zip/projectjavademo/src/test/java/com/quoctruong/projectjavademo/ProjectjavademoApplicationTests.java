package com.quoctruong.projectjavademo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectjavademoApplicationTests {

	@Test
	void contextLoads() {
	}

}
