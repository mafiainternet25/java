# Upgrade Progress

  ### ❗ Generate Upgrade Plan [View Log](logs/1.generatePlan.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  #### Errors
  - Failed to get git status for /home/quoctruong/Documents/JAVA/projectjavademo-v26/projectjavademo-v22/projectjavademo-v20/projectjavademo-v9/projectjavademo: fatal: not a git repository (or any of the parent directories): .git
  </details>